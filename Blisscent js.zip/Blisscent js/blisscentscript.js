'use strict';



/**
 * add event on element
 */

const addEventOnElem = function (elem, type, callback) {
  if (elem.length > 1) {
    for (let i = 0; i < elem.length; i++) {
      elem[i].addEventListener(type, callback);
    }
  } else {
    elem.addEventListener(type, callback);
  }
}



/**
 * navbar toggle
 */

const navTogglers = document.querySelectorAll("[data-nav-toggler]");
const navbar = document.querySelector("[data-navbar]");
const navbarLinks = document.querySelectorAll("[data-nav-link]");
const overlay = document.querySelector("[data-overlay]");

const toggleNavbar = function () {
  navbar.classList.toggle("active");
  overlay.classList.toggle("active");
}

addEventOnElem(navTogglers, "click", toggleNavbar);

const closeNavbar = function () {
  navbar.classList.remove("active");
  overlay.classList.remove("active");
}

addEventOnElem(navbarLinks, "click", closeNavbar);



/**
 * header sticky & back top btn active
 */

const header = document.querySelector("[data-header]");
const backTopBtn = document.querySelector("[data-back-top-btn]");

const headerActive = function () {
  if (window.scrollY > 150) {
    header.classList.add("active");
    backTopBtn.classList.add("active");
  } else {
    header.classList.remove("active");
    backTopBtn.classList.remove("active");
  }
}

addEventOnElem(window, "scroll", headerActive);

let lastScrolledPos = 0;

const headerSticky = function () {
  if (lastScrolledPos >= window.scrollY) {
    header.classList.remove("header-hide");
  } else {
    header.classList.add("header-hide");
  }

  lastScrolledPos = window.scrollY;
}

addEventOnElem(window, "scroll", headerSticky);



/**
 * scroll reveal effect
 */

const sections = document.querySelectorAll("[data-section]");

const scrollReveal = function () {
  for (let i = 0; i < sections.length; i++) {
    if (sections[i].getBoundingClientRect().top < window.innerHeight / 2) {
      sections[i].classList.add("active");
    }
  }
}

scrollReveal();

addEventOnElem(window, "scroll", scrollReveal);

// Function to introduce a delay (in ms) 
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Function to auto-scroll the slider items and loop back to the first one
async function autoScrollSlides() {
    const slides = document.getElementById('slider'); // Get the slider
    const totalSlides = document.querySelectorAll('.scrollbar-item').length; // Get total slides
    let currentSlideIndex = 0;

    while (true) {
        // Wait for 3 seconds before moving to the next slide
        await delay(3000);

        // Update the transform property to scroll to the next slide
        currentSlideIndex = (currentSlideIndex + 1) % totalSlides; // Loop back to the first slide after the last one
        const translateX = -100 * currentSlideIndex;  // Calculate the translate value based on the current slide index

        slides.style.transform = `translateX(${translateX}%)`;  // Apply the translation to create a sliding effect

        // Reset to the first slide when we reach the last slide
        if (currentSlideIndex === 0) {
            // Allow a brief time for the last slide to show before resetting
            await delay(3000); // Delay before resetting
            slides.style.transition = 'none'; // Disable transition temporarily
            slides.style.transform = 'translateX(0%)'; // Reset to the first slide
            await delay(50); // Brief wait before re-enabling transition
            slides.style.transition = 'transform 1s ease'; // Re-enable the transition
        }
    }
}

// Call the function to start auto-scrolling
autoScrollSlides();
// Show the popup after 5 seconds
window.onload = function() {
    setTimeout(function() {
        document.getElementById("popup").style.display = "flex";
    }, 7000);  // Popup will appear after 5 seconds
}

// Function to close the popup
function closePopup() {
    document.getElementById("popup").style.display = "none";
}
