// Initialize Locomotive Scroll
const scroll = new LocomotiveScroll({
    el: document.querySelector('[data-scroll-container]'),
    smooth: true
});

// When "Take Quiz" button is clicked, redirect to another page
document.getElementById("takeQuizBtn").addEventListener("click", function() {
    window.location.href = "quiz.html"; // Replace with the actual link to your quiz page
});

// When "Discover More" button is clicked, scroll down to the three-steps section
document.getElementById("discoverMoreBtn").addEventListener("click", function() {
    document.getElementById("threeSteps").scrollIntoView({ behavior: 'smooth' });
});
// Add functionality for switching personality types (Optional)
const personalityBtns = document.querySelectorAll('.personality-btn');
personalityBtns.forEach(button => {
    button.addEventListener('click', function() {
        document.querySelector('.personality-btn.active').classList.remove('active');
        this.classList.add('active');

        // Change content based on personality type clicked (you can customize this)
        // For now, content is static, but you can load dynamic content here
    });
});
const personalityData = {
    authentic: {
        title: "THE AUTHENTIC",
        traits: ["RELIABLE", "CONSISTENT", "LOYAL", "CLASSY"],
        text: "For you, nothing is greater than respecting life’s values and being genuine. In this superficial world, you find beauty in the flaws and imperfections that make each one of us unique.",
        image: "https://i.pinimg.com/736x/20/9d/27/209d27b81814eea8ef1d2f2e3acd00bb.jpg",  // The image file for 'THE AUTHENTIC'
        scentStyle: [
            { icon: "fas fa-water", label: "Refreshing" },
            { icon: "fas fa-leaf", label: "Natural" },
            { icon: "fas fa-flask", label: "Pure" },
            { icon: "fas fa-clock", label: "Long Lasting" }
        ]
    },
    enthusiast: {
        title: "THE SOCIAL ENTHUSIAST",
        traits: ["CHARISMATIC", "ENERGETIC", "CONFIDENT", "FRIENDLY"],
        text: "You thrive in social situations and love connecting with others. Your vibrant energy is contagious, making you the life of every gathering.",
        image: "https://i.pinimg.com/564x/ce/d6/de/ced6de07c60e7718c8f723d76f51cd4c.jpg",  // The uploaded image
        scentStyle: [
            { icon: "fas fa-bolt", label: "Bold" },
            { icon: "fas fa-fire", label: "Spicy" },
            { icon: "fas fa-sun", label: "Vibrant" },
            { icon: "fas fa-wind", label: "Warm" }
        ]
    },
    spirit: {
        title: "THE FREE SPIRIT",
        traits: ["ADVENTUROUS", "CREATIVE", "UNPREDICTABLE", "INDEPENDENT"],
        text: "You embrace life's spontaneity and enjoy exploring the unknown. Your sense of freedom and creativity shines in everything you do.",
        image: "https://i.pinimg.com/564x/04/0c/d0/040cd0ce62fe3a6398dd28079e2baf66.jpg",  // Placeholder
        scentStyle: [
            { icon: "fas fa-leaf", label: "Citrusy" },
            { icon: "fas fa-flower", label: "Floral" },
            { icon: "fas fa-seedling", label: "Earthy" },
            { icon: "fas fa-wind", label: "Fresh" }
        ]
    },
    extraordinary: {
        title: "THE EXTRAORDINARY",
        traits: ["BOLD", "UNIQUE", "IMAGINATIVE", "FEARLESS"],
        text: "You stand out from the crowd and love expressing your individuality. Ordinary is not in your vocabulary, and you live life on your own terms.",
        image: "https://i.pinimg.com/736x/2b/b5/b4/2bb5b41a01cf6e41e6d86710caed6e62.jpg",  // Placeholder
        scentStyle: [
            { icon: "fas fa-globe", label: "Exotic" },
            { icon: "fas fa-flask", label: "Deep" },
            { icon: "fas fa-mask", label: "Mysterious" },
            { icon: "fas fa-brain", label: "Complex" }
        ]
    },
    connoisseur: {
        title: "THE CONNOISSEUR",
        traits: ["SOPHISTICATED", "REFINED", "DISCERNING", "ELEGANT"],
        text: "With a taste for the finer things in life, you appreciate quality and craftsmanship. You have a discerning nose for what’s truly exquisite.",
        image: "https://i.pinimg.com/564x/42/fd/86/42fd864d5187280b3ecdacf533c677f3.jpg",  // Placeholder
        scentStyle: [
            { icon: "fas fa-gem", label: "Luxurious" },
            { icon: "fas fa-crown", label: "Rich" },
            { icon: "fas fa-wine-glass", label: "Smooth" },
            { icon: "fas fa-clock", label: "Timeless" }
        ]
    }
};

const buttons = document.querySelectorAll('.personality-btn');
const titleElement = document.getElementById('personality-title');
const traitsElement = document.getElementById('traits');
const textElement = document.getElementById('personality-text');
const imageElement = document.getElementById('personality-image');
const scentStyleElement = document.querySelector('.scent-style');

buttons.forEach(button => {
    button.addEventListener('click', function() {
        // Remove 'active' class from all buttons and add it to the clicked one
        document.querySelector('.personality-btn.active').classList.remove('active');
        this.classList.add('active');

        // Get the type from the clicked button
        const type = this.getAttribute('data-type');
        const data = personalityData[type];

        // Update the content
        titleElement.textContent = data.title;
        traitsElement.innerHTML = data.traits.map(trait => `<span class="trait">${trait}</span>`).join('');
        textElement.textContent = data.text;
        imageElement.src = data.image;  // Update image source

        // Update the scent style icons
        scentStyleElement.innerHTML = data.scentStyle.map(scent => `
            <div class="scent-item">
                <i class="${scent.icon}"></i> ${scent.label}
            </div>
        `).join('');
    });
});
function animateCounter(id, start, end, duration) {
    const obj = document.getElementById(id);
    let current = start;
    const range = end - start;
    const increment = end > start ? 1 : -1;
    const stepTime = Math.abs(Math.floor(duration / range));
    const timer = setInterval(function() {
        current += increment;
        obj.textContent = current;
        if (current == end) {
            clearInterval(timer);
        }
    }, stepTime);
}

// Function to check when the counter section is in view
function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return rect.top <= (window.innerHeight || document.documentElement.clientHeight);
}

// Start counter when the section is in view
window.addEventListener('scroll', function() {
    const counterSection = document.getElementById('quiz-counter');
    const quizCompleted = document.getElementById('quiz-completed');
    if (isElementInViewport(counterSection) && quizCompleted.textContent === '0') {
        animateCounter('quiz-completed', 0, 1845, 10000);  // Change 18450 to your dynamic count
    }
});
// FAQ Toggle functionality
const faqItems = document.querySelectorAll('.faq-item');

faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    
    question.addEventListener('click', () => {
        item.classList.toggle('active');
        
        faqItems.forEach(otherItem => {
            if (otherItem !== item) {
                otherItem.classList.remove('active');
            }
        });
    });
});

 document.getElementById('takeQuizBtn').addEventListener('click', function() {
        window.location.href = '1.html'; // Replace 'quiz.html' with the URL or page you want to open
    });


