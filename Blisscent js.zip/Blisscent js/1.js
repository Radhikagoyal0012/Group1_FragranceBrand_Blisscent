// Scroll to the Age Section
function scrollToAgeSection() {
    const ageSection = document.getElementById('age-section');
    ageSection.scrollIntoView({ behavior: 'smooth' });
}

// Update the displayed age based on the slider value
function updateAge(value) {
    const ageLabel = document.getElementById('selected-age');
    ageLabel.innerText = value; // Update the age label
}

// Scroll to the Gender Section
function scrollToGenderSection() {
    const genderSection = document.getElementById('gender-section');
    genderSection.scrollIntoView({ behavior: 'smooth' });
}

// Toggle dropdown info visibility
function toggleDropdown() {
    const dropdown = document.getElementById('dropdown-info');
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
}

// Scroll to Skin Tone Section when any gender is selected
function scrollToSkinToneSection() {
    const skinToneSection = document.getElementById('skin-tone-section');
    skinToneSection.scrollIntoView({ behavior: 'smooth' });
}

// Toggle skin tone dropdown info visibility
function toggleSkinToneDropdown() {
    const dropdown = document.getElementById('skin-tone-info');
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
}
// Scroll to the Personality Section when a skin tone option is selected
function scrollToPersonalitySection() {
    const personalitySection = document.getElementById('personality-section');
    personalitySection.scrollIntoView({ behavior: 'smooth' });
}
// Ensure the arrow is connected to the scroll functionality
document.getElementById('scroll-arrow').addEventListener('click', function() {
    const targetSection = document.getElementById('which-matters-section');
    
    // Smooth scroll to the "Which Matters" section
    if (targetSection) {
        targetSection.scrollIntoView({
            behavior: 'smooth'
        });
    }
});


// Handle option click
const options = document.querySelectorAll('.option');
options.forEach(option => {
    option.addEventListener('click', function() {
        // Remove 'selected' class from all options
        options.forEach(opt => opt.classList.remove('selected'));
        
        // Add 'selected' class to the clicked option
        option.classList.add('selected');

        // Scroll down to the next section (if any)
        setTimeout(() => {
            const nextSection = document.getElementById('next-section-id'); // Adjust the next section ID if there's another one
            if (nextSection) {
                nextSection.scrollIntoView({ behavior: 'smooth' });
            }
        }, 500); // Delay to allow animation to complete
    });
});
// Handle option click for 'Which Comes Most Naturally' section
const optionsNaturally = document.querySelectorAll('.comes-naturally-section .option');
optionsNaturally.forEach(option => {
    option.addEventListener('click', function() {
        // Remove 'selected' class from all options
        optionsNaturally.forEach(opt => opt.classList.remove('selected'));

        // Add 'selected' class to the clicked option
        option.classList.add('selected');

        // Scroll down to the next section
        setTimeout(() => {
            const nextSection = document.getElementById('next-section-id'); // Adjust to the next section ID
            if (nextSection) {
                nextSection.scrollIntoView({ behavior: 'smooth' });
            }
        }, 500); // Delay to allow animation to complete
    });
});

// Scroll to the Age Section
function scrollToComesNaturallySection() {
    const comesNaturallySection = document.getElementById('comes-naturally-section');
    comesNaturallySection.scrollIntoView({ behavior: 'smooth' });
}



// Optional: Add event listeners to the options
document.querySelectorAll('.options-container .option').forEach(option => {
    option.addEventListener('click', scrollToOlfactiveSection); // Attach scroll function to each option
});

function scrollToNextSection() {
    const nextSection = document.querySelector('#next-section-id');
    if (nextSection) {
        nextSection.scrollIntoView({ behavior: 'smooth' });
    }
}

// Handle option selection
document.querySelectorAll('.option-box').forEach(option => {
    option.addEventListener('click', function () {
        // Remove 'selected' class from all options
        document.querySelectorAll('.option-box').forEach(opt => opt.classList.remove('selected'));

        // Add 'selected' class to the clicked option
        this.classList.add('selected');
    });
});
// Add functionality to limit selection to 2 checkboxes
const checkboxes = document.querySelectorAll('.form-check-input');

checkboxes.forEach(checkbox => {
    checkbox.addEventListener('change', () => {
        let checkedCount = document.querySelectorAll('.form-check-input:checked').length;
        if (checkedCount >= 2) {
            checkboxes.forEach(cb => {
                if (!cb.checked) cb.disabled = true;
            });
        } else {
            checkboxes.forEach(cb => cb.disabled = false);
        }
    });
});

// Function to scroll to the Olfactive Section
function scrollToOlfactiveSection() {
    const olfactiveSection = document.querySelector('.olfactive-section');
    olfactiveSection.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
}

// Function to scroll to the Olfactive Preference Section
function scrollToOlfactivePreferenceSection() {
    const olfactivePreferenceSection = document.querySelector('.olfactive-preference-section');
    olfactivePreferenceSection.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
}

// Function to scroll to the Container Fluid Section after selecting from the Olfactive Preference Section
function scrollToContainerFluidSection() {
    const containerFluidSection = document.querySelector('.container-fluid');
    containerFluidSection.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
}

// Function to scroll to the Container Section after selecting from the Container Fluid Section
function scrollToContainerSection() {
    const containerSection = document.querySelector('.container.py-5');
    containerSection.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
}
// Function to scroll to the Gender Section when 'Next' is clicked in Age Section
function scrollToGenderSection() {
    const genderSection = document.querySelector('.olfactive-preference-section');
    genderSection.scrollIntoView({ behavior: 'smooth' });
}

// Function to scroll to the Skin Tone Section when any Gender option is clicked
function scrollToSkinToneSection() {
    const skinToneSection = document.querySelector('.skin-tone-section'); // Make sure to add an ID or class to the skin tone section
    skinToneSection.scrollIntoView({ behavior: 'smooth' });
}

// Update the selected age dynamically as the user interacts with the age slider
function updateAge(value) {
    document.getElementById('selected-age').textContent = value;
}
// Function to scroll to the Skin Tone Section when any Gender option is clicked
function scrollToSkinToneSection() {
    const skinToneSection = document.querySelector('.skin-tone-section'); // Ensure the skin tone section has the class 'skin-tone-section'
    skinToneSection.scrollIntoView({ behavior: 'smooth' });
}
// Function to scroll to the Olfactive Preference Section when the arrow is clicked
function scrollToOlfactivePreferenceSection() {
    const olfactivePreferenceSection = document.getElementById('olfactive-preference-section');
    olfactivePreferenceSection.scrollIntoView({ behavior: 'smooth' });
}
// Function to scroll to the recommendation section
    function scrollToRecommendationSection() {
        const recommendationSection = document.getElementById('recommendation-section');
        recommendationSection.scrollIntoView({ behavior: 'smooth' });
    }

    // Attach event listener to the "Next" button
    document.getElementById('nextButton').addEventListener('click', scrollToRecommendationSection);
	
 document.getElementById('takeQuizBtn').addEventListener('click', function() {
        window.location.href = 'quiz1.html'; // Replace 'quiz.html' with the URL or page you want to open
    });